from socket import *
import random

def main():
    serverSocket = socket(AF_INET, SOCK_STREAM)
    serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
    serverSocket.bind(('', 4343))
    serverSocket.listen()
    print("Servidor aguardando conexoes...")

    while True:
        connectionSocket1, addr1 = serverSocket.accept()
        print("Jogador 1 conectado:", addr1[0])

        connectionSocket2, addr2 = serverSocket.accept()
        print("Jogador 2 conectado:", addr2[0])

        players = [connectionSocket1, connectionSocket2]
        random.shuffle(players)
        current_player_index = 0
        other_player_index = 1

        try:
            if current_player_index == 0:
                print("Jogador 1 começa a partida.")
            else:
                print("Jogador 2 começa a partida.")

            # Inicializa o tabuleiro vazio
            board = [['-' for _ in range(3)] for _ in range(3)]
            total_moves = 0

            while True:
                current_player_socket = players[current_player_index]
                other_player_socket = players[other_player_index]

                send_board(current_player_socket, board)
                send_board(other_player_socket, board)

                # Verifica condições de vitória
                if check_winner(board):
                    send_message(current_player_socket, "Você venceu!")
                    send_message(other_player_socket, "Você perdeu!")
                    break

                # Verifica empate
                if total_moves == 9:
                    send_message(current_player_socket, "Empate!")
                    send_message(other_player_socket, "Empate!")
                    break

                send_message(current_player_socket, "Sua vez de jogar.")
                move = receive_move(current_player_socket, board)

                row, col = move // 3, move % 3
                board[row][col] = 'X' if current_player_index == 0 else 'O'
                total_moves += 1

                # Troca os jogadores
                current_player_index, other_player_index = other_player_index, current_player_index

        except Exception as e:
            print("Erro:", e)

        connectionSocket1.close()
        connectionSocket2.close()
        serverSocket.close()

def send_message(socket, message):
    socket.send(message.encode())

def send_board(socket, board):
    socket.send("Tabuleiro:\n".encode())
    for row in board:
        socket.send(' '.join(row).encode())
        socket.send('\n'.encode())
    socket.send("\n".encode())

def receive_move(socket, board):
    while True:
        move = int(socket.recv(1024).decode())
        if is_valid_move(move, board):
            return move
        send_message(socket, "Jogada inválida. Tente novamente.")

def is_valid_move(move, board):
    row, col = move // 3, move % 3
    return 0 <= row < 3 and 0 <= col < 3 and board[row][col] == '-'

def check_winner(board):
    # Verifica linhas
    for row in board:
        if row[0] == row[1] == row[2] != '-':
            return True

    # Verifica colunas
    for col in range(3):
        if board[0][col] == board[1][col] == board[2][col] != '-':
            return True

    # Verifica diagonais
    if board[0][0] == board[1][1] == board[2][2] != '-' or board[0][2] == board[1][1] == board[2][0] != '-':
        return True

    return False

if __name__ == '__main__':
    main()
