from socket import *
import random
#import os

# Função que formata o tabuleiro em forma de string para enviar aos jogadores
def matrixToString(table):
    string = ' {} | {} | {}\n-----------\n {} | {} | {}\n-----------\n {} | {} | {} '.format(
        table[0][0],
        table[0][1],
        table[0][2],
        table[1][0],
        table[1][1],
        table[1][2],
        table[2][0],
        table[2][1],
        table[2][2]
    )
    return string

# Função que verifica o vencedor com base nas posições da matriz
def checkWinner(table):
    # As posições que devem ser verificadas são:
    # Linha, coluna ou diagonal (principal ou secundária) preenchida pelo mesmo jogador
    for i in range(3):
        # Verificando linhas e colunas
        if table[i][0] == table[i][1] == table[i][2] != ' ' or table[0][i] == table[1][i] == table[2][i] != ' ':
            return True
    # Verificando diagonais
    if table[0][0] == table[1][1] == table[2][2] != ' ' or table[0][2] == table[1][1] == table[2][0] != ' ':
        return True
    return False

# Função que verifica se a jogada enviada pelo cliente é válida ou não
def checkMove(table, move):
    # Verifica se a entrada do jogador é um número
    if not isinstance(move, int):
        return False
    # Verifica se a posição está dentro dos limites do tabuleiro
    if move < 1 or move > 9:
        return False
    row = (move - 1) // 3
    col = (move - 1) % 3
    # Verifica se a posição está vazia
    if table[row][col] != ' ':
        return False
    return True


# Função que gerencia a partida
def managePlay(conn1, conn2):
    # Inicializando o tabuleiro vazio
    table = [[' ' for _ in range(3)] for _ in range(3)]
    # Enviando mensagem de início de jogo para os clientes
    conn1.send("Você é o jogador 1. Aguarde o outro jogador fazer a sua jogada.\n".encode())
    conn2.send("Você é o jogador 2. Aguarde sua vez de jogar.\n".encode())
    # Determinando aleatoriamente quem começa o jogo
    current_player = random.choice([conn1, conn2])
    # Loop do jogo
    while True:
        # Enviando tabuleiro atualizado para os jogadores
        message = "Tabuleiro atual:\n" + matrixToString(table) + "\n"
        conn1.send(message.encode())
        conn2.send(message.encode())
        # Recebendo jogada do jogador da vez
        current_player.send("Sua vez de jogar. Escolha uma posição (0-8): ".encode())
        while True:
            move = int(current_player.recv(1024).decode().strip())
            # Verificando se a jogada é válida
            if not checkMove(table, move):
                current_player.send("Jogada inválida. Tente novamente.\n".encode())
                continue
            row = (move - 1) // 3
            col = (move - 1) % 3
            # Marcando a jogada no tabuleiro
            table[row][col] = 'X' if current_player == conn1 else 'O'
            break  # Sai do loop enquanto se a jogada for válida

        # Verificando se há um vencedor ou empate
        if checkWinner(table):
            message = "Tabuleiro final:\n" + matrixToString(table) + "\n"
            message += "Parabéns! Você venceu!\n" if current_player == conn1 else "Você perdeu!\n"
            conn1.send(message.encode())
            conn2.send(message.encode())
            break
        elif all([cell != ' ' for row in table for cell in row]):
            message = "Tabuleiro final:\n" + matrixToString(table) + "\n"
            message += "Empate!\n"
            conn1.send(message.encode())
            conn2.send(message.encode())
            break
        # Alternando o jogador da vez
        current_player = conn1 if current_player == conn2 else conn2

def main():
    # Criando o socket do cliente
    client_socket = socket(AF_INET, SOCK_STREAM)
    client_socket.connect(('localhost', 4343))

    while True:
        # Recebendo mensagem do servidor
        message = client_socket.recv(1024).decode()
        # Limpando a tela e mostrando a mensagem
        #os.system('clear')
        print(message)
        if "Sua vez de jogar" in message:
            # Solicitando jogada ao usuário
            move = int(input("Escolha uma posição (0-8): "))
            client_socket.send(str(move).encode())
        elif "Parabéns!" in message or "Empate!" in message:
            # Exibindo mensagem de fim de jogo
            print(message)
        # Verificando se o servidor encerrou a conexão
        if not message:
            break

if __name__ == '__main__':
    main()